from base import make_magic_class, Field, MagicClass, make_magic_value_class


fnf_number = make_magic_value_class('fnf_number', 0, meta={'name': 'number'})
fnf_bool = make_magic_value_class('fnf_bool', False, meta={'name': 'bool'})

binary_number_fields = (Field(fnf_number, dict(name='a')), Field(fnf_number, dict(name='b')), Field(fnf_number, dict(name='r')))

class add(object):
    meta = {'name': '+'}
    fields = binary_number_fields
    @staticmethod
    def init(self):
        pass
    
    @staticmethod
    def modified(self, field, self_modified):
        if self_modified:
            return
        #assert field in self.cls.fields, "unknown field modified in magic class"
        mod_instance = self.get_subfield_instance((field,), False)
        fields_by_name = self.fields_by_name()
        field_instances_by_name = self.field_instances_by_name()
        a,b,r = field_instances_by_name.values()
        
        if mod_instance in (a,b):
            r_res = a.meta['value'] + b.meta['value']
            self.modify_field(fields_by_name['r'], fnf_number.create_instance(meta={'value': r_res}), True)
        else:
            b_res = r.meta['value'] - a.meta['value']
            self.modify_field(fields_by_name['b'], fnf_number.create_instance(meta={'value': b_res}), True)

add = make_magic_class(add)
        
        


if __name__=='__main__':
    try:
        a = add.create_instance()
        a.modify_field(a.fields_by_name()['a'], fnf_number.create_instance(meta={'value': 1}))
    except:
        import pdb
        #pdb.pm()
        raise
